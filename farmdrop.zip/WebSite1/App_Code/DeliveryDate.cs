﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeliveryDate
/// </summary>
public class DeliveryDate
{
    private String deliverydate;
	public DeliveryDate()
	{
		//
		// TODO: Add constructor logic here
		//
        deliverydate = DateTime.Now.ToString();
	}
}