﻿using System;
/// <summary>
///UserType 的摘要说明
/// </summary>
public enum UserType
{
    Admin, Member, Client
}
